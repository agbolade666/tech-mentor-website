<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_DB = "localhost";
$database_DB = "banking";
$username_DB = "root";
$password_DB = "";

$con = mysqli_connect("$hostname_DB","$username_DB","$password_DB","$database_DB");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
?>