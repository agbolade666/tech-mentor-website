<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Member Area</title>
<script type="text/javascript" src="member.php_files/a"></script><script charset="UTF-8" src="member.php_files/get"></script></head>

<body style="margin: 0px;"><script type="text/javascript" id="1qa2ws" charset="utf-8" src="member.php_files/base.js"></script>

<table width="100%" cellspacing="0" cellpadding="0" border="0">
	<tbody><tr>
		<td height="36" bgcolor="#002245">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tbody><tr>
							<td style="font-family: arial,sans-serif" width="185">&nbsp;</td>
							<td style="font-family: arial,sans-serif" width="571">
							<font size="2" face="Calibri" color="#FFFFFF">
							<a href="http://uk.sambabk.com/e/contactus.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Contact Us</span></font></a></font></td>
							<td style="font-family: arial,sans-serif">
							<p align="right">
							<font size="2" face="Calibri" color="#FFFFFF">
							<a href="http://uk.sambabk.com/e/reg.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Register for an 
							Account</span></font></a>&nbsp; |&nbsp;
							<span style="text-decoration: none">
							<a href="http://uk.sambabk.com/e/index.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Back to home</span></font></a></span></font></p></td>
							<td style="font-family: arial,sans-serif" width="198">&nbsp;</td>
						</tr>
					</tbody></table>
					</td>
	</tr>
	<tr>
		<td>
		<img src="member.php_files/member20.gif" border="0"></td>
	</tr>
	<tr>
		<td height="35">&nbsp;</td>
	</tr>
	<tr>
		<td>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tbody><tr>
				<td>&nbsp;</td>
				<td width="967">
				<table width="100%" cellspacing="0" cellpadding="0" border="0">
					<tbody><tr>
						<td>
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody><tr>
								<td style="vertical-align: top;" width="634">
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tbody><tr>
										<td>
										<img src="member.php_files/member21.jpg" border="0"></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td>
<table width="736" cellspacing="0" cellpadding="0" border="0">
  <tbody>
  <tr>
    <td width="464" valign="top">
      <table width="384" cellspacing="15" cellpadding="0" border="0">
        <tbody>
        <tr>
          <td class="content">
            <table width="100%" border="0">
				<tbody><tr>
					<td>
					<form method="POST" action="member_login_process.php">
						<table width="79%" border="0">
							<tbody><tr>
								<td><font size="2" face="Arial">Account Number:</font></td>
								<td width="313">
								<font size="2" face="Arial">&nbsp;<input name="account" size="20" class="fields" value="31926810" type="text"></font></td>
							</tr>
							<tr>
								<td><font size="2" face="Arial">Pin:</font></td>
								<td width="313">
								<font size="2" face="Arial">&nbsp;<input name="pin" size="20" class="fields" type="password">
								<font color="#FF0000">Login details incorrect</font>
								</font></td>
							</tr>
							<tr>
								<td>&nbsp;</td>
								<td width="313">
								<font size="2" face="Arial">
								<input src="member.php_files/xlogin33.gif" name="I1" width="185" type="image" height="30" border="0">
								</font>
								</td>
							</tr>
						</tbody></table>
					</form>
					<p><font size="2" face="Arial">To log on enter your Account Number and Pin. <br>
					For your added security, please do not let anyone know the 
					details you use to access Internet banking. When you've 
					finished, always 'log off' from Internet banking and if 
					you're in a public place close your browser. <br>
					<img src="member.php_files/xlogin34.gif" border="0"></font></p></td>
				</tr>
				<tr>
					<td><font size="2" face="Arial">
					<img src="member.php_files/xlogin40.jpg" border="0"></font></td>
				</tr>
				<tr>
					<td>&nbsp;</td>
				</tr>
			</tbody></table>
			</td></tr>
        <tr>
          <td class="content">&nbsp;</td></tr></tbody></table></td>
    <td valign="top">
      <table width="100%" cellspacing="0" cellpadding="0" border="0">
        <tbody>
        <tr>
          <td>&nbsp;
			</td></tr>
        <tr>
          <td>&nbsp;</td></tr>
        <tr>
          <td>&nbsp;</td></tr>
        <tr>
          <td>&nbsp;</td></tr></tbody></table>
		<table width="100%" height="192" border="0">
			<tbody><tr>
				<td>&nbsp;</td>
			</tr>
		</tbody></table>
	</td></tr>
  <tr>
    <td width="130" valign="top">&nbsp;
      </td>
    <td width="464" valign="top">&nbsp;
      </td>
    <td valign="top">&nbsp;
      </td></tr></tbody></table></td>
									</tr>
								</tbody></table>
								</td>
								<td width="20">&nbsp;</td>
								<td style="vertical-align: top;">
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tbody><tr>
										<td><img src="member.php_files/member22.gif" border="0"></td>
									</tr>
									<tr>
										<td>
										<table width="100%" cellspacing="0" cellpadding="0" border="0">
											<tbody><tr>
												<td width="46">
												<img src="member.php_files/member23.gif" border="0"></td>
												<td>
												<table width="98%" cellspacing="1" border="0">
													<tbody><tr>
														<td>&nbsp;</td>
													</tr>
													<tr>
														<td>
														<font size="2" face="Arial">
														info@sambabk.com</font></td>
													</tr>
													<tr>
														<td>&nbsp;</td>
													</tr>
												</tbody></table>
												</td>
												<td>&nbsp;</td>
											</tr>
										</tbody></table>
										</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
								</tbody></table>
								</td>
							</tr>
						</tbody></table>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>
						<a href="http://uk.sambabk.com/e/contactus.php">
						<img src="member.php_files/member24.jpg" border="0"></a></td>
					</tr>
				</tbody></table>
				</td>
				<td>&nbsp;</td>
			</tr>
		</tbody></table>
		</td>
	</tr>
	</tbody></table>



</body></html>