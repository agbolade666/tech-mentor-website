
<!-- saved from url=(0058)http://uk.sambabk.com/e/customer_area.php?account=31926818 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Error</title>
<style type="text/css"></style></head>

<body style="margin: 0px;">

][
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tbody><tr>
		<td bgcolor="#002245" height="36">
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tbody><tr>
							<td width="185" style="font-family: arial,sans-serif">&nbsp;</td>
							<td width="571" style="font-family: arial,sans-serif">
							<font color="#FFFFFF" face="Calibri" size="2">
							<a href="contactus.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Contact Us</span></font></a></font></td>
							<td style="font-family: arial,sans-serif">
							<p align="right">
							<font face="Calibri" color="#FFFFFF" size="2">
							<a href="Registration.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Register for an 
							Account</span></font></a>&nbsp; |&nbsp;
							<span style="text-decoration: none">
							<a href="index.html"><font color="#FFFFFF">
						  <span style="text-decoration: none">Back to home</span></font></a></span></font></p></td>
							<td width="198" style="font-family: arial,sans-serif">&nbsp;</td>
						</tr>
					</tbody></table>
					</td>
	</tr>
	<tr>
		<td>
		<img border="0" src="./error1_files/member20.gif"></td>
	</tr>
	<tr>
		<td height="35">&nbsp;</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tbody><tr>
				<td>&nbsp;</td>
				<td width="967">
				<table border="0" width="100%" cellspacing="0" cellpadding="0">
					<tbody><tr>
						<td>
						<table border="0" width="100%" cellspacing="0" cellpadding="0">
							<tbody><tr>
								<td style="vertical-align: top;" width="800">
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tbody><tr>
										<td>
										<font face="Georgia" size="6" color="#000080">
										Online Services</font></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td>
										<iframe name="I1" width="926" height="569" border="0" frameborder="0" src="./error1_files/transfer_1_error.php">
				Your browser does not support inline frames or is currently configured not to display inline frames.
				</iframe></td>
									</tr>
								</tbody></table>
								</td>
								<td width="20">&nbsp;</td>
								<td style="vertical-align: top;">&nbsp;
								</td>
							</tr>
						</tbody></table>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>
						<a href="http://uk.sambabk.com/e/contactus.php">
						<img border="0" src="./error1_files/member24.jpg"></a></td>
					</tr>
				</tbody></table>
				</td>
				<td>&nbsp;</td>
			</tr>
		</tbody></table>
		</td>
	</tr>
	</tbody></table>



</body></html>