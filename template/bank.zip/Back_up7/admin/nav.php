	<table border="0" width="85%" height="23">
														<tr>
															<td width="88" align="center" bgcolor="#122744">
															  <h5><font color="#FFFFFF">
														      <b>
														      <a href="addclient.php">
												            <font color="#FFFFFF">Add Client</font></a></b></font></h5></td>
															<td width="86" align="center" bgcolor="#122744">
															  <h5><font color="#FFFFFF">
														      <b>
														      <!-- <a href="viewclients.php"> -->
															  <a href="addclient.php">
															  
												            <font color="#FFFFFF">View Clients</font></a></b></font></h5></td>
															<td align="center" bgcolor="#122744" width="66">
															  <h5><font color="#FFFFFF">
														      <b>
														      <a href="logout.php">
												            <font color="#FFFFFF">Log Out</font></a></b></font></h5></td>
															<td align="center" bgcolor="#122744">
															  <h5><font color="#FFFFFF">
														      <b>
														      <!-- <a href="view_apps.php"> -->
															  <a href="addclient.php">
															  
													          <font color="#FFFFFF">View All 
												            Applications</font></a></b></font></h5></td>
														</tr>
													</table>