

<tr>
				<td width="392"><font size="-1">Welcome <?php echo ucwords($_SESSION["Name"]). "&nbsp;" .ucwords($_SESSION["LastName"]); ?></font></td>
				<td></td>
				<td width="176">
			    <p align="right"><font size="-1">
				Today: <b> <?php echo date("d F Y"); ?> </b></font></td>
			</tr>

</font>
