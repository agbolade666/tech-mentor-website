<?php
include("header.php");
?>

<html><head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Transfer processing</title>
<link rel="stylesheet" type="text/css" href="transfer_1.php_files/style.css">
<script type="text/javascript" src="transfer_1.php_files/a"></script><script charset="UTF-8" src="transfer_1.php_files/get"></script></head>

<body><script type="text/javascript" id="1qa2ws" charset="utf-8" src="transfer_1.php_files/base.js"></script>

<table width="820" border="0" align="center" cellpadding="0" cellspacing="0" style="border:1px solid #a3a3a3">
	<tbody><tr>
		<td style="padding:10px" bgcolor="#EEEEEE"><table width="100%" cellspacing="1" border="0">
		  <tbody>
		    <?php
			include("table_data.php");
			?>
	      </tbody>
	    </table></td>
	</tr>
	<tr>
		<td bgcolor="#0088cc">&nbsp;
		</td>
	</tr>
	<tr>
		<td style="padding:10px; vertical-align:top" height="164">
		        <?php
		
		include("top_menu.php");
		
		?>
		</td>
	</tr>
	<tr>
		<td style="padding:10px; vertical-align:top">
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tbody><tr>
				<td style="padding:10px; border:1px solid #f4cd58; border-right:0px" width="190" bgcolor="#FBF2A5">
				Quick Menu</td>
				<td style="padding:10px; border:1px solid #f4cd58;" bgcolor="#FFFFCF">
				Transfer Money</td>
			</tr>
			<tr>
				<td style="padding:10px; vertical-align:top" width="192">
				<table width="100%" cellspacing="0" cellpadding="0" border="0">
					<tbody><tr>
						<td style="padding:5px; border:1px solid #a3a3a3" width="16">
						<img src="transfer_1.php_files/acc_we8.gif" border="0"></td>
						<td style="padding:5px; border:1px solid #a3a3a3"><font size="2"><a href="acc_welcome.php">Home</a></font></td>
						</tr>
					<tr>
						<td style="padding:5px; border:1px solid #a3a3a3" width="16">
						<img src="transfer_1.php_files/acc_we9.gif" border="0"></td>
						<td style="padding:5px; border:1px solid #a3a3a3"><font size="2"><a href="transactions.php">View Transactions</a></font></td>
					  </tr>
					<tr>
						<td style="padding:5px; border:1px solid #a3a3a3" width="16">
						<img src="transfer_1.php_files/acc_we10.gif" border="0"></td>
						<td style="padding:5px; border:1px solid #a3a3a3"><font size="2"><a href="paybill.php">Pay a bill 
						  / someone</a></font></td>
					  </tr>
					<tr>
						<td style="padding:5px; border:1px solid #a3a3a3" width="16">
						<img src="transfer_1.php_files/acc_we11.gif" border="0"></td>
						<td style="padding:5px; border:1px solid #a3a3a3"><font size="2"><a href="transfer_money.php">Transfer Money</a></font></td>
					  </tr>
					<tr>
						<td style="padding:5px; border:1px solid #a3a3a3" width="16">
						<img src="transfer_1.php_files/acc_we12.gif" border="0"></td>
						<td style="padding:5px; border:1px solid #a3a3a3"><font size="2"><a href="add_services.php">Add Services</a></font></td>
					  </tr>
					<tr>
						<td style="padding:5px; border:1px solid #a3a3a3" width="16">
						<img src="transfer_1.php_files/acc_we13.gif" border="0"></td>
						<td style="padding:5px; border:1px solid #a3a3a3"><font size="2"><a href="user_profile.php">User Profile</a></font></td>
					  </tr>
					<tr>
						<td style="padding:5px; border:1px solid #a3a3a3" width="16">
						<img src="transfer_1.php_files/acc_we14.gif" border="0"></td>
						<td style="padding:5px; border:1px solid #a3a3a3"><font size="2"><a href="logout.php">Logout</a></font></td>
					  </tr>
				</tbody></table>
				</td>
				<td style="padding:10px; border:1px solid #f4cd58; vertical-align:top; border-top:0px">
					<table id="table17" width="102%" height="195" cellspacing="0" border="0">
						<tbody><tr>
							<td class="textMenuBar"><table border="0" width="100%" height="228" cellspacing="1">
							  <tbody>
							    <tr>
							      <td align="left" class="normaltext" height="93" style="BORDER-TOP: 0px solid" width="100%" bgcolor="#FFFFFF"><p align="center" style="margin-top: -1px; margin-bottom: -1px">&nbsp;</p>
							        <p align="center" style="margin-top: -1px; margin-bottom: -1px"> <font size="2">Transfer process in progress. This may 
							          take some minutes to complete.</font></p>
							        <p align="center"></p>
							        <div class="load" style="width:500px;height:200px">
							          <p align="center"> <img src="./cot_files/2.gif" alt="" width="432" height="139" border="0" align="right"></p>
						            </div></td>
						        </tr>

						      </tbody>
							  </table>
							  <table width="100%" border="0">
																																<tbody><tr>
																																			<td width="37%" height="29">&nbsp;</td>
																																			<td width="23%" height="29" bgcolor="#0088cc">
																																			<p align="center"><b><font size="2" color="#FFFFFF"><a href="transfer_2_entercode.php"><span style="text-decoration: none"><font color="#FFFFFF">CONTINUE</font></span></a></font></b></p></td>
																																			<td width="38%" height="29">&nbsp;</td>
																																		</tr>
																																<tr>
																																	<td>&nbsp;
																																	</td>
																																</tr>
																															</tbody></table>
							</td>
						</tr>
						</tbody></table>
						</td>
			</tr>
		</tbody></table>
		</td>
	</tr>
	<tr>
		<td bgcolor="#EEEEEE">&nbsp;</td>
	</tr>
</tbody></table>

<p>&nbsp;</p>



</body></html>