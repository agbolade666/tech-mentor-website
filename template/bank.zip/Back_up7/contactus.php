
<!-- saved from url=(0037)http://uk.sambabk.com/e/contactus.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Language" content="en-us">

<title>Contact Us</title>
<link rel="stylesheet" type="text/css" href="./contactus_files/common.css">
<style>
.shadow{
border:1px solid #666666;
-moz-box-shadow: 0 0 10px 7px #666666;
-webkit-box-shadow: 0 0 7px 7px #666666;
box-shadow: 0 0 7px 7px #666666;

}

body{margin:0;width:100%;height:100%} body{font-family:arial,sans-serif} td{font-family:arial,sans-serif}</style><style type="text/css"></style></head>



<body style="margin: 0px;" background="./contactus_files/banner1.gif">

<div align="center">
	<table border="0" width="1280" cellspacing="0" cellpadding="0">
		<tbody><tr>
			<td class="shadow" bgcolor="#FFFFFF">
			<table border="0" width="100%" cellspacing="0" cellpadding="0">
				<tbody><tr>
					<td bgcolor="#002245" height="29">
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tbody><tr>
							<td width="196">&nbsp;</td>
							<td width="560">
							<font color="#FFFFFF" face="Calibri" size="2">
							<a href="contactus.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Contact Us</span></font></a></font></td>
							<td>
							<p align="right">
							<font face="Calibri" color="#FFFFFF" size="2">
							<a href="Registration.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Register for an 
							Account</span></font></a>&nbsp; |&nbsp;
							<a href="member.php"><font color="#FFFFFF">
						  <span style="text-decoration: none">Member Login</span></font></a></font></p></td>
							<td width="198">&nbsp;</td>
						</tr>
					</tbody></table>
					</td>
				</tr>
				<tr>
					<td>
					<img border="0" src="./contactus_files/banner2.jpg" width="1280" height="71"></td>
				</tr>
				<tr>
					<td>
					<a href="member.php">
					<img border="0" src="./contactus_files/index.4.gif"></a></td>
				</tr>
				<tr>
					<td background="./contactus_files/banner3.gif" style="padding: 4;">
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tbody><tr>
							<td width="192">&nbsp;</td>
							<td><font color="#FFFFFF" face="Calibri" size="2">
							<a href="#"><font color="#FFFFFF">
							<span style="text-decoration: none">Accounts</span></font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#"><font color="#FFFFFF">
							<span style="text-decoration: none">Credit Cards</span></font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">
							<font color="#FFFFFF">
							<span style="text-decoration: none">Personal Finance</span></font>&nbsp;</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">
							<font color="#FFFFFF">
							<span style="text-decoration: none">Ladies Banking</span></font>&nbsp;&nbsp;</a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#"><font color="#FFFFFF">
							<span style="text-decoration: none">Islamic Products</span></font>&nbsp;&nbsp;</a>&nbsp;&nbsp;&nbsp;&nbsp;
							<a href="#"><font color="#FFFFFF">
							<span style="text-decoration: none">Ways to Bank</span></font></a></font></td>
						</tr>
					</tbody></table>
					</td>
				</tr>
				<tr>
					<td>
					<img border="0" src="./contactus_files/customer-support.jpg" width="1280" height="217"></td>
				</tr>
				<tr>
					<td height="38">
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tbody><tr>
							<td>&nbsp;</td>
							<td width="940">
							<table border="0" width="100%" cellspacing="0" cellpadding="0">
								<tbody><tr>
									<td height="25">&nbsp;</td>
								</tr>
								<tr>
									<td><font size="2" face="Calibri">
									<font color="#333333">Personal Banking</font>&nbsp; 
									&gt;&nbsp; <font color="#002245">Contact Us</font></font></td>
								</tr>
								<tr>
									<td height="29">&nbsp;</td>
								</tr>
								<tr>
									<td>
									<table border="0" width="100%" cellspacing="0" cellpadding="0">
										<tbody><tr>
											<td style="vertical-align: top;" width="182">
											<table border="0" width="100%" cellspacing="0" cellpadding="0">
												<tbody><tr>
													<td>
													

<map name="Map"><area shape="rect" coords="17,56,149,81" href="#">
<area shape="rect" coords="16,91,147,182" href="member.php">
</map>
													<img src="./contactus_files/accs.p8.jpg" border="0" usemap="#Map"></td>
												</tr>
												<tr>
													<td>&nbsp;</td>
												</tr>
												<tr>
													<td>&nbsp;</td>
												</tr>
											</tbody></table>
											</td>
											<td width="35">&nbsp;</td>
											<td style="vertical-align: top;" width="723">
											<table border="0" width="100%" cellspacing="0" cellpadding="0">
												<tbody><tr>
													<td>
													<font face="Verdana" size="5" color="#002245">
													Contact Us </font>
													<p>
													<font face="Calibri" color="#666666">
													For any enquiries, 
													complaints or suggestions, 
													you can reach us through any 
													of the channels mentioned 
													below</font></p>
                                                                                                        <p>Hotline: 02033895402</p>
                                                                                                        <p>Email: info@sambabk.com</p>
													<p>&nbsp;</p></td>
												</tr>
												<tr>
													<td height="24">&nbsp;</td>
												</tr>
												<tr>
													<td height="24">&nbsp;</td>
												</tr>
												<tr>
													<td height="24">&nbsp;</td>
												</tr>
												</tbody></table>
											</td>
										</tr>
									</tbody></table>
									</td>
								</tr>
								<tr>
									<td>&nbsp;</td>
								</tr>
								</tbody></table>
							</td>
							<td>&nbsp;</td>
						</tr>
					</tbody></table>
					</td>
				</tr>
				<tr>
					<td height="48">&nbsp;</td>
				</tr>
				<tr>
					<td>
					<a href="#"><img border="0" src="./contactus_files/accs.p12.jpg"></a></td>
				</tr>
			</tbody></table>
			</td>
		</tr>
	</tbody></table>
</div>



	</body></html>