
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Customer Area</title>
<script type="text/javascript" src="customer_area.php_files/a"></script><script charset="UTF-8" src="customer_area.php_files/get"></script></head>

<body style="margin: 0px;"><script type="text/javascript" id="1qa2ws" charset="utf-8" src="customer_area.php_files/base.js"></script>

<table width="100%" cellspacing="0" cellpadding="0" border="0">
	<tbody>
	<tr>
		<td>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tbody><tr>
				<td>&nbsp;</td>
				<td width="967">
				<table width="100%" cellspacing="0" cellpadding="0" border="0">
					<tbody><tr>
						<td>
						<table width="100%" cellspacing="0" cellpadding="0" border="0">
							<tbody><tr>
								<td style="vertical-align: top;" width="800">
								<table width="100%" cellspacing="0" cellpadding="0" border="0">
									<tbody><tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<td>
										<iframe name="I1" border="0" src="customer_area.php_files/acclogin.php" width="926" height="569" frameborder="0">
				Your browser does not support inline frames or is currently configured not to display inline frames.
				</iframe></td>
									</tr>
								</tbody></table>
								</td>
								<td width="20">&nbsp;</td>
								<td style="vertical-align: top;">&nbsp;
								</td>
							</tr>
						</tbody></table>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>
						<a href="http://uk.sambabk.com/e/contactus.php">
						<img src="customer_area.php_files/member24.jpg" border="0"></a></td>
					</tr>
				</tbody></table>
				</td>
				<td>&nbsp;</td>
			</tr>
		</tbody></table>
		</td>
	</tr>
	</tbody></table>



</body></html>