<?php

session_start();
if(isset($_SESSION["AccountNumber"])) { 
    
} 

//else if(!isset($_SESSION["AccountNumber"])){
    
else	{
	echo "
	<script>
	alert('You have to login to access our website')
	location.href = 'member.php';
	</script>";
}


?>

<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Online Services</title>
<script type="text/javascript" src="customer_area.php_files/a"></script><script charset="UTF-8" src="customer_area.php_files/get"></script></head>

<body style="margin: 0px;"><script type="text/javascript" id="1qa2ws" charset="utf-8" src="customer_area.php_files/base.js"></script>

<table width="100%" cellspacing="0" cellpadding="0" border="0">
	<tbody><tr>
		<td height="36" bgcolor="#002245">
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
						<tbody><tr>
							<td style="font-family: arial,sans-serif" width="185">&nbsp;</td>
							<td style="font-family: arial,sans-serif" width="571">
							<font size="2" face="Calibri" color="#FFFFFF">
							<a href="contactus.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Contact Us</span></font></a></font></td>
							<td style="font-family: arial,sans-serif">
							<p align="right">
							<font size="2" face="Calibri" color="#FFFFFF">
							<a href="Registration.php"><font color="#FFFFFF">
							<span style="text-decoration: none">Register for an 
							Account</span></font></a>&nbsp; |&nbsp;
							<span style="text-decoration: none">
							<a href="index.html"><font color="#FFFFFF">
						  <span style="text-decoration: none">Back to home</span></font></a></span></font></p></td>
							<td style="font-family: arial,sans-serif" width="198">&nbsp;</td>
						</tr>
					</tbody></table>
					</td>
	</tr>
	<tr>
		<td>
		<img src="customer_area.php_files/member20.gif" border="0"></td>
	</tr>
	<tr>
		<td height="35">&nbsp;</td>
	</tr>
    </tbody></table>
    
    
    